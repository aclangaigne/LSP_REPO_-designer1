package org.howard.edu.lsp.finale.question1;

/**
 * Singleton service that delegates password generation to a pluggable algorithm.
 */
public class PasswordGeneratorService {
    private static PasswordGeneratorService instance;
    private PasswordAlgorithm algorithm;

    private PasswordGeneratorService() {}

    /**
     * Returns the single shared instance of this service.
     */
    public static synchronized PasswordGeneratorService getInstance() {
        if (instance == null) {
            instance = new PasswordGeneratorService();
        }
        return instance;
    }

    /**
     * Selects the algorithm to use for password generation.
     * @param name "basic", "enhanced", or "letters"
     */
    public void setAlgorithm(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Algorithm name cannot be null");
        }
        switch (name.toLowerCase()) {
            case "basic":
                algorithm = new BasicPasswordAlgorithm();
                break;
            case "enhanced":
                algorithm = new EnhancedPasswordAlgorithm();
                break;
            case "letters":
                algorithm = new LettersPasswordAlgorithm();
                break;
            default:
                throw new IllegalArgumentException("Unknown algorithm: " + name);
        }
    }

    /**
     * Generates a password with the configured algorithm.
     * @param length desired password length
     * @return generated password
     */
    public String generatePassword(int length) {
        if (algorithm == null) {
            throw new IllegalStateException("Algorithm not set");
        }
        if (length <= 0) {
            throw new IllegalArgumentException("length must be > 0");
        }
        return algorithm.generate(length);
    }

    /*
     * DESIGN PATTERNS
     * ---------------
     * 1. Singleton Pattern
     *    The PasswordGeneratorService class is implemented as a Singleton.
     *    - It has a private constructor.
     *    - It exposes a public static getInstance() method.
     *    - Only one instance of the service can exist.
     *
     *    Rationale:
     *    The exam requirements specify a "single, shared access point" for
     *    password generation (Expectation #5 from Part A). By using the
     *    Singleton pattern, the same service instance is reused throughout the
     *    application, ensuring all clients interact with the same configured
     *    password generator.
     *
     *
     * 2. Strategy Pattern
     *    PasswordAlgorithm is the Strategy interface. The classes:
     *       - BasicPasswordAlgorithm
     *       - EnhancedPasswordAlgorithm
     *       - LettersPasswordAlgorithm
     *    are concrete strategies implementing different password-generation
     *    approaches.
     *
     *    The method setAlgorithm(String name) dynamically selects which
     *    strategy to use at runtime, without changing the service or client
     *    code.
     *
     *    Rationale:
     *    This directly satisfies Expectations #1–4 from Part A:
     *      (1) Multiple password approaches are supported by creating different
     *          algorithm classes.
     *      (2) The caller selects the approach at run time via setAlgorithm().
     *      (3) New algorithms can be added in the future simply by creating
     *          another PasswordAlgorithm implementation—no changes to the
     *          service or test code are required.
     *      (4) The behavior is fully swappable: setAlgorithm(...) replaces the
     *          active strategy used by generatePassword(int length).
     *
     *
     * Summary:
     * The Singleton pattern enforces a single global service instance, while the
     * Strategy pattern enables clean separation of password-generation behaviors
     * and makes the system extensible and flexible. Together, these patterns
     * meet all architectural expectations outlined in the exam instructions.
     */
}
