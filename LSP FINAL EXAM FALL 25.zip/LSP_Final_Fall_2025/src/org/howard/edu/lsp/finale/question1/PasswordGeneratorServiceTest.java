package org.howard.edu.lsp.finale.question1;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class PasswordGeneratorServiceTest {

    private PasswordGeneratorService service;

    @BeforeEach
    public void setup() {
        service = PasswordGeneratorService.getInstance();
    }

    @Test
    public void checkInstanceNotNull() {
        assertNotNull(service);
    }

    @Test
    public void checkSingleInstanceBehavior() {
        PasswordGeneratorService second = PasswordGeneratorService.getInstance();
        // Must be the same object in memory
        assertSame(service, second);
    }

    @Test
    public void generateWithoutSettingAlgorithmThrowsException() {
        PasswordGeneratorService s = PasswordGeneratorService.getInstance();
        // We expect IllegalStateException if no algorithm is selected
        assertThrows(IllegalStateException.class, () -> s.generatePassword(5));
    }

    @Test
    public void basicAlgorithmGeneratesCorrectLengthAndDigitsOnly() {
        service.setAlgorithm("basic");
        String p = service.generatePassword(10);
        assertEquals(10, p.length());
        assertTrue(p.chars().allMatch(Character::isDigit));
    }

    @Test
    public void enhancedAlgorithmGeneratesCorrectCharactersAndLength() {
        service.setAlgorithm("enhanced");
        String p = service.generatePassword(12);
        assertEquals(12, p.length());
        assertTrue(p.chars().allMatch(c -> Character.isLetterOrDigit(c)));
    }

    @Test
    public void lettersAlgorithmGeneratesLettersOnly() {
        service.setAlgorithm("letters");
        String p = service.generatePassword(8);
        assertEquals(8, p.length());
        assertTrue(p.chars().allMatch(Character::isLetter));
    }

    @Test
    public void switchingAlgorithmsChangesBehavior() {
        service.setAlgorithm("basic");
        String p1 = service.generatePassword(10);

        service.setAlgorithm("letters");
        String p2 = service.generatePassword(10);

        service.setAlgorithm("enhanced");
        String p3 = service.generatePassword(10);

        // basic: digits only
        assertTrue(p1.chars().allMatch(Character::isDigit));
        // letters: letters only
        assertTrue(p2.chars().allMatch(Character::isLetter));
        // enhanced: letters and/or digits
        assertTrue(p3.chars().allMatch(c -> Character.isLetterOrDigit(c)));

        assertEquals(10, p1.length());
        assertEquals(10, p2.length());
        assertEquals(10, p3.length());
    }
}
