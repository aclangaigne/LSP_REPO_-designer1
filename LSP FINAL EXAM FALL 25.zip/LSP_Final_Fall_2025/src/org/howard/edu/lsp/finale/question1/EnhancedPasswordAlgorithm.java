package org.howard.edu.lsp.finale.question1;

import java.security.SecureRandom;

/**
 * Enhanced algorithm: letters + digits using SecureRandom.
 */
public class EnhancedPasswordAlgorithm implements PasswordAlgorithm {
    private static final String CHARS =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
            "abcdefghijklmnopqrstuvwxyz" +
            "0123456789";
    private final SecureRandom random = new SecureRandom();

    @Override
    public String generate(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(CHARS.length());
            sb.append(CHARS.charAt(index));
        }
        return sb.toString();
    }
}
